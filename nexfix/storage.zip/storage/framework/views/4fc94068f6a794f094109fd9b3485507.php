<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2>Bookings List</h2>
        <a href="<?php echo e(route('bookings.create')); ?>" class="btn btn-primary mb-3">Add Booking</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered" id="bookingsTable">
            <thead>
                <tr>
                    
                    <th>User</th>
                    <th>Service</th>
                    <th>Vendor</th>
                    <th>Booking Date</th>
                    <th>Scheduled At</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Payment Method</th>
                    <th>User Status</th> 
                    <th>Vendor Status</th> 
                    <th>Notes</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="booking-<?php echo e($booking->id); ?>">
                        
                        <td><?php echo e($booking->user->name ?? 'N/A'); ?></td>
                        <td><?php echo e($booking->service->name ?? 'N/A'); ?></td>

                        <!-- Vendor Dropdown -->


                        <td><?php echo e($booking->vendor->company_name ?? '-'); ?></td>


                        <td><?php echo e($booking->booking_date); ?></td>
                        <td><?php echo e($booking->scheduled_at ?? '-'); ?></td>
                        <td><?php echo e($booking->total_amount ?? '0.00'); ?></td>

                        <!-- Payment Dropdown -->
                        <td>
                            <select class="form-select payment-select" data-id="<?php echo e($booking->id); ?>">
                                <?php $__currentLoopData = ['unpaid', 'paid', 'refunded']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pay); ?>"
                                        <?php echo e($booking->payment_status == $pay ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst($pay)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>

                        <td><?php echo e($booking->payment_method ?? 'not paid'); ?></td>
                        <!-- 🟢 CHANGED: Split status into two dropdowns -->

                        <!-- User Status Dropdown -->
                        <td>
                            <select class="form-select status-user-select" data-id="<?php echo e($booking->id); ?>">
                                <option value="">--</option>
                                <?php $__currentLoopData = ['completed', 'cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($stat); ?>"
                                        <?php echo e($booking->status_user == $stat ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst($stat)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>

                        <!-- Vendor Status Dropdown -->
                        <td>
                            <select class="form-select status-vendor-select" data-id="<?php echo e($booking->id); ?>">
                                <option value="">--</option>
                                <?php $__currentLoopData = ['accepted', 'completed', 'cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($stat); ?>"
                                        <?php echo e($booking->status_vendor == $stat ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst($stat)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>

                        <td><?php echo e($booking->notes ?? '-'); ?></td>

                        <td class="d-flex justify-center align-items-center gap-3">
                            <!-- AJAX Update button -->
                            <button class="btn btn-success btn-sm update-booking d-flex align-items-center gap-1"
                                data-id="<?php echo e($booking->id); ?>">
                                <i class="fa fa-sync-alt"></i> Update
                            </button>

                            <!-- Edit button -->
                            <a href="<?php echo e(route('bookings.edit', $booking->id)); ?>" class="btn btn-warning btn-sm">
                                <i class="fa fa-edit"></i>
                            </a>

                            <!-- Delete button -->
                            <form action="<?php echo e(route('bookings.destroy', $booking->id)); ?>" method="POST"
                                style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Are you sure?')">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- 🟢 CHANGED: Updated AJAX Script -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).on('click', '.update-booking', function() {
            let id = $(this).data('id');
            let vendor_id = $(`#booking-${id} .vendor-select`).val();
            let payment_status = $(`#booking-${id} .payment-select`).val();
            let status_user = $(`#booking-${id} .status-user-select`).val();
            let status_vendor = $(`#booking-${id} .status-vendor-select`).val();

            $.ajax({
                url: `/admin/bookings/${id}/ajax-update`,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    vendor_id: vendor_id,
                    payment_status: payment_status,
                    status_user: status_user,
                    status_vendor: status_vendor
                },
                success: function(response) {
                    alert(response.message);
                },
                error: function(xhr) {
                    alert('Update failed: ' + xhr.responseJSON?.message);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\bookings\index.blade.php ENDPATH**/ ?>