<?php $__env->startSection('content'); ?>
<h2>Service Categories</h2>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<a href="<?php echo e(route('service-categories.create')); ?>" class="btn btn-primary mb-3 float-end">Add Category</a>

<table class="table table-bordered my-5">
    <thead>
        <tr>
            <th>ID</th>
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($category->id); ?></td>
            <td>
                <?php if($category->image): ?>
                    <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="Category Image" width="70">
                <?php else: ?>
                    <small>No Image</small>
                <?php endif; ?>
            </td>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->description); ?></td>
            <td>
                <a href="<?php echo e(route('service-categories.edit', $category->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                <form action="<?php echo e(route('service-categories.destroy', $category->id)); ?>" method="POST" style="display:inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\service_categories\index.blade.php ENDPATH**/ ?>