<?php $__env->startSection('content'); ?>
<h2>Edit Service Category</h2>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('service-categories.update', $serviceCategory->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-2">
        <label>Name</label>
        <input type="text" name="name" class="form-control" value="<?php echo e($serviceCategory->name); ?>" required>
    </div>
    <div class="mb-2">
        <label>Description</label>
        <textarea name="description" class="form-control"><?php echo e($serviceCategory->description); ?></textarea>
    </div>
    <div class="mb-2">
        <label>Current Image</label><br>
        <?php if($serviceCategory->image): ?>
            <img src="<?php echo e(asset('storage/' . $serviceCategory->image)); ?>" alt="Category Image" width="100">
        <?php else: ?>
            <small>No Image</small>
        <?php endif; ?>
    </div>
    <div class="mb-2">
        <label>Change Image</label>
        <input type="file" name="image" class="form-control" accept="image/*">
    </div>
    <button type="submit" class="btn btn-success">Update Category</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\service_categories\edit.blade.php ENDPATH**/ ?>