<?php if (isset($component)) { $__componentOriginal3964b5c455d4068b187a7fb9baf5a459 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3964b5c455d4068b187a7fb9baf5a459 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portal.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3964b5c455d4068b187a7fb9baf5a459)): ?>
<?php $attributes = $__attributesOriginal3964b5c455d4068b187a7fb9baf5a459; ?>
<?php unset($__attributesOriginal3964b5c455d4068b187a7fb9baf5a459); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3964b5c455d4068b187a7fb9baf5a459)): ?>
<?php $component = $__componentOriginal3964b5c455d4068b187a7fb9baf5a459; ?>
<?php unset($__componentOriginal3964b5c455d4068b187a7fb9baf5a459); ?>
<?php endif; ?>

<body>
    <?php if (isset($component)) { $__componentOriginal9481f42310b2986b58c21a6635ae3119 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9481f42310b2986b58c21a6635ae3119 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userDashboard.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userDashboard.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9481f42310b2986b58c21a6635ae3119)): ?>
<?php $attributes = $__attributesOriginal9481f42310b2986b58c21a6635ae3119; ?>
<?php unset($__attributesOriginal9481f42310b2986b58c21a6635ae3119); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9481f42310b2986b58c21a6635ae3119)): ?>
<?php $component = $__componentOriginal9481f42310b2986b58c21a6635ae3119; ?>
<?php unset($__componentOriginal9481f42310b2986b58c21a6635ae3119); ?>
<?php endif; ?>
<style>
   /* Sidebar */
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
        width: 230px;
        background: #ffffff;
        border-right: 1px solid #e5e5e5;
        padding-top: 70px;
        box-shadow: 4px 0 8px rgba(0, 0, 0, 0.03);
    }

    .sidebar a {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        color: #333;
        font-weight: 500;
        text-decoration: none;
        border-radius: 8px;
        margin: 6px 15px;
        transition: all 0.25s ease;
    }

    .sidebar a:hover,
    .sidebar a.active {
        background-color: #81c408;
        color: #fff;
        transform: translateX(5px);
    }

    .sidebar a i {
        margin-right: 10px;
        font-size: 1.1rem;
    }

</style>
    <!-- Sidebar -->
    <div class="sidebar" style="padding-top: 100px">


        <?php
            if (Auth::check()) {
                $role = Auth::user()->role; // assuming 'role' column exists
                $dashboardUrl = url("$role/dashboard");
            } else {
                $dashboardUrl = route('login');
            }
        ?>

        <a href="<?php echo e($dashboardUrl); ?>" class="active">
            <i class="bi bi-speedometer2"></i> Dashboard</i>
        </a>


        <a href="<?php echo e(route('user.myBooking')); ?>"><i class="bi bi-calendar-check"></i> My Bookings</a>
        <a href="#"><i class="bi bi-wallet2"></i> Payments</a>
        <a href="#"><i class="bi bi-chat-dots"></i> Messages</a>
        <a href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-person-circle"></i> Profile</a>


    </div>

    <main>
        
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php if (isset($component)) { $__componentOriginal4294bdea13e99034632c8d2d2b35e749 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4294bdea13e99034632c8d2d2b35e749 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portal.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4294bdea13e99034632c8d2d2b35e749)): ?>
<?php $attributes = $__attributesOriginal4294bdea13e99034632c8d2d2b35e749; ?>
<?php unset($__attributesOriginal4294bdea13e99034632c8d2d2b35e749); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4294bdea13e99034632c8d2d2b35e749)): ?>
<?php $component = $__componentOriginal4294bdea13e99034632c8d2d2b35e749; ?>
<?php unset($__componentOriginal4294bdea13e99034632c8d2d2b35e749); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\components\userDashboard\layout.blade.php ENDPATH**/ ?>