<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Vendors List</h2>
    <a href="<?php echo e(route('vendors.create')); ?>" class="btn btn-primary mb-3">Add Vendor</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th><th>Company</th><th>User</th><th>Phone</th><th>Verified</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($vendor->id); ?></td>
                    <td><?php echo e($vendor->company_name); ?></td>
                    <td><?php echo e($vendor->user->name); ?></td>
                    <td><?php echo e($vendor->phone); ?></td>
                    <td><?php echo e($vendor->verified ? 'Yes' : 'No'); ?></td>
                    <td>
                        <a href="<?php echo e(route('vendors.edit', $vendor->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('vendors.destroy', $vendor->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Delete vendor?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($vendors->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\vendors\index.blade.php ENDPATH**/ ?>