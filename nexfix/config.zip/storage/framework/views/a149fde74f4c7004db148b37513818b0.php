<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Vendor</h2>
    <form method="POST" action="<?php echo e(route('vendors.update', $vendor->id)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label>Company Name</label>
            <input type="text" name="company_name" value="<?php echo e($vendor->company_name); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo e($vendor->phone); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Address</label>
            <input type="text" name="address" value="<?php echo e($vendor->address); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Verified</label>
            <input type="checkbox" name="verified" value="1" <?php echo e($vendor->verified ? 'checked' : ''); ?>>
        </div>
        <button class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\vendors\edit.blade.php ENDPATH**/ ?>