<?php if (isset($component)) { $__componentOriginal3964b5c455d4068b187a7fb9baf5a459 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3964b5c455d4068b187a7fb9baf5a459 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portal.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3964b5c455d4068b187a7fb9baf5a459)): ?>
<?php $attributes = $__attributesOriginal3964b5c455d4068b187a7fb9baf5a459; ?>
<?php unset($__attributesOriginal3964b5c455d4068b187a7fb9baf5a459); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3964b5c455d4068b187a7fb9baf5a459)): ?>
<?php $component = $__componentOriginal3964b5c455d4068b187a7fb9baf5a459; ?>
<?php unset($__componentOriginal3964b5c455d4068b187a7fb9baf5a459); ?>
<?php endif; ?>
    

<body>

   <?php if (isset($component)) { $__componentOriginale428438d6a796fc87d49371e9311adfd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale428438d6a796fc87d49371e9311adfd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portal.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale428438d6a796fc87d49371e9311adfd)): ?>
<?php $attributes = $__attributesOriginale428438d6a796fc87d49371e9311adfd; ?>
<?php unset($__attributesOriginale428438d6a796fc87d49371e9311adfd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale428438d6a796fc87d49371e9311adfd)): ?>
<?php $component = $__componentOriginale428438d6a796fc87d49371e9311adfd; ?>
<?php unset($__componentOriginale428438d6a796fc87d49371e9311adfd); ?>
<?php endif; ?>

<main>
    <?php echo e($slot); ?>

</main>
    
  <?php if (isset($component)) { $__componentOriginal4294bdea13e99034632c8d2d2b35e749 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4294bdea13e99034632c8d2d2b35e749 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('portal.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4294bdea13e99034632c8d2d2b35e749)): ?>
<?php $attributes = $__attributesOriginal4294bdea13e99034632c8d2d2b35e749; ?>
<?php unset($__attributesOriginal4294bdea13e99034632c8d2d2b35e749); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4294bdea13e99034632c8d2d2b35e749)): ?>
<?php $component = $__componentOriginal4294bdea13e99034632c8d2d2b35e749; ?>
<?php unset($__componentOriginal4294bdea13e99034632c8d2d2b35e749); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\components\portal\layout.blade.php ENDPATH**/ ?>