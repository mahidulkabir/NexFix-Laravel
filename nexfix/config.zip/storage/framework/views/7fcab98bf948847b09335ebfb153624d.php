<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Profit & Revenue Report</h2>
        <form class="d-flex gap-2" method="GET" action="<?php echo e(route('admin.reports.index')); ?>">
            <input type="date" name="start_date" class="form-control" value="<?php echo e($start); ?>">
            <input type="date" name="end_date" class="form-control" value="<?php echo e($end); ?>">
            <button type="submit" class="btn btn-primary">Filter</button>
            <?php if($start || $end): ?>
                <a href="<?php echo e(route('admin.reports.index')); ?>" class="btn btn-outline-secondary">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 rounded-4 bg-light">
                <div class="card-body text-center py-4">
                    <h6 class="text-muted mb-2">Total Revenue</h6>
                    <h3 class="fw-bold text-primary">$<?php echo e(number_format($totalRevenue, 2)); ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 rounded-4 bg-light">
                <div class="card-body text-center py-4">
                    <h6 class="text-muted mb-2">Total Vendor Earnings</h6>
                    <h3 class="fw-bold text-success">$<?php echo e(number_format($totalVendorEarnings, 2)); ?></h3>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 rounded-4 bg-light">
                <div class="card-body text-center py-4">
                    <h6 class="text-muted mb-2">Admin Profit</h6>
                    <h3 class="fw-bold text-danger">$<?php echo e(number_format($totalAdminProfit, 2)); ?></h3>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card shadow-sm rounded-4">
        <div class="card-body">
            <h5 class="fw-semibold mb-3">Monthly Overview</h5>
            <canvas id="profitChart" height="120"></canvas>
        </div>
    </div>

    
    <div class="card shadow-sm rounded-4 mt-4">
        <div class="card-body">
            <h5 class="fw-semibold mb-3">Monthly Breakdown</h5>
            <table class="table table-striped table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Month</th>
                        <th>Total Revenue</th>
                        <th>Vendor Earnings</th>
                        <th>Profit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $monthlyStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::create()->month($stat->month)->format('F')); ?></td>
                            <td>$<?php echo e(number_format($stat->total_revenue, 2)); ?></td>
                            <td>$<?php echo e(number_format($stat->vendor_earning, 2)); ?></td>
                            <td class="fw-semibold text-danger">$<?php echo e(number_format($stat->profit, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($monthlyStats->isEmpty()): ?>
                        <tr><td colspan="4" class="text-center text-muted">No data available.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('profitChart');
    const months = <?php echo json_encode($monthlyStats->pluck('month')->map(fn($m) => \Carbon\Carbon::create()->month($m)->format('M')), 15, 512) ?>;
    const revenue = <?php echo json_encode($monthlyStats->pluck('total_revenue'), 15, 512) ?>;
    const vendor = <?php echo json_encode($monthlyStats->pluck('vendor_earning'), 15, 512) ?>;
    const profit = <?php echo json_encode($monthlyStats->pluck('profit'), 15, 512) ?>;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: months,
            datasets: [
                {
                    label: 'Revenue',
                    data: revenue,
                    borderColor: '#0d6efd',
                    fill: false,
                    tension: 0.3
                },
                {
                    label: 'Vendor Earnings',
                    data: vendor,
                    borderColor: '#198754',
                    fill: false,
                    tension: 0.3
                },
                {
                    label: 'Admin Profit',
                    data: profit,
                    borderColor: '#dc3545',
                    fill: false,
                    tension: 0.3
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\dashboard\admin.blade.php ENDPATH**/ ?>