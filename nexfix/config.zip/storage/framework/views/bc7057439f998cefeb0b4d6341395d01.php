<?php $__env->startSection('content'); ?>
<h1>Welcome, <?php echo e(auth()->user()->name); ?>!</h1>
<p>Manage your platform here. Ok?</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.vendor_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\dashboard\vendor.blade.php ENDPATH**/ ?>