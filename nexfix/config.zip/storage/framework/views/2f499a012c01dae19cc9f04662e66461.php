<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Services</h2>
    <a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary mb-3">Add Service</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

   <table class="table table-bordered">
    <thead>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Details</th>
            <th>Category</th>
            <th>Description</th>
            <th>Base Price</th>
            <th>Active</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($service->image): ?>
                        <img src="<?php echo e(asset('storage/'.$service->image)); ?>" alt="Service Image" width="70" height="70" style="object-fit:cover; border-radius:8px;">
                    <?php else: ?>
                        <span class="text-muted">No Image</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($service->name); ?></td>
                <td><?php echo e($service->details); ?></td>

                <td><?php echo e($service->category->name ?? 'N/A'); ?></td>
                <td>
                    <?php echo e(\Illuminate\Support\Str::limit($service->description, 50, '...')); ?>

                </td>
                <td><?php echo e($service->base_price); ?></td>
                <td><?php echo e($service->active ? 'Yes' : 'No'); ?></td>
                <td>
                    <a href="<?php echo e(route('services.edit', $service)); ?>" class="btn btn-sm btn-info">Edit</a>
                    <form action="<?php echo e(route('services.destroy', $service)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this service?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


    <?php echo e($services->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\services\index.blade.php ENDPATH**/ ?>