<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\user\user_dashboard.blade.php ENDPATH**/ ?>