<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>All Reviews</h2>
    <a href="<?php echo e(route('reviews.create')); ?>" class="btn btn-primary mb-3">Add Review</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Booking</th>
                <th>User</th>
                <th>Vendor</th>
                <th>Rating</th>
                <th>Comment</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($review->id); ?></td>
                <td><?php echo e($review->booking->id ?? 'N/A'); ?></td>
                <td><?php echo e($review->user->name ?? 'N/A'); ?></td>
                <td><?php echo e($review->vendor->name ?? 'N/A'); ?></td>
                <td><?php echo e($review->rating); ?></td>
                <td><?php echo e($review->comment); ?></td>
                <td>
                    <a href="<?php echo e(route('reviews.edit', $review->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('reviews.destroy', $review->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete this review?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\reviews\index.blade.php ENDPATH**/ ?>