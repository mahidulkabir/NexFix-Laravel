<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="fw-bold text-primary mb-4">Vendor Payout Management</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success text-center rounded-pill py-2"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($payouts->count() > 0): ?>
        <div class="card shadow-sm rounded-4 border-0">
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Vendor</th>
                                <th>Booking ID</th>
                                <th>Total Amount</th>
                                <th>Admin Commission</th>
                                <th>Vendor Earnings</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($payout->vendor->company_name ?? 'N/A'); ?></td>
                                    <td>#<?php echo e($payout->booking_id); ?></td>
                                    <td><strong><?php echo e(number_format($payout->total_amount, 2)); ?></strong> ৳</td>
                                    <td class="text-danger">-<?php echo e(number_format($payout->commission_amount, 2)); ?> ৳</td>
                                    <td class="text-success"><?php echo e(number_format($payout->vendor_earning, 2)); ?> ৳</td>
                                    <td>
                                        <?php if($payout->status === 'paid'): ?>
                                            <span class="badge bg-success-subtle text-success border border-success">Paid</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning-subtle text-warning border border-warning">Pending</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($payout->created_at->format('d M, Y')); ?></td>
                                    <td>
                                        <?php if($payout->status === 'pending'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.payouts.markPaid', $payout->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-primary rounded-pill px-3 py-1">
                                                    <i class="fa fa-check me-1"></i> Mark Paid
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-success rounded-pill px-3 py-1" disabled>
                                                <i class="fa fa-check-circle me-1"></i> Paid
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fa fa-wallet text-secondary fs-1 mb-3"></i>
            <p class="lead text-muted">No payouts available yet.</p>
        </div>
    <?php endif; ?>
</div>

<style>
    .bg-success-subtle { background-color: #eaf8ef !important; }
    .bg-warning-subtle { background-color: #fff6e5 !important; }
    table th { white-space: nowrap; }
    .btn { transition: all .2s ease; }
    .btn:hover { transform: translateY(-2px); }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\payouts\index.blade.php ENDPATH**/ ?>