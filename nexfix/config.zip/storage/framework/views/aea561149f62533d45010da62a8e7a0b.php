<?php echo $__env->make('layouts.partials.vendor_header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<body class="font-sans antialiased bg-gray-100 min-h-screen flex flex-col">

    
    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    
    <?php echo $__env->make('layouts.partials.vendor_sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    

        
        <main class="p-4" style="margin-left:250px; margin-top:70px;">
            <?php echo $__env->yieldContent('content'); ?>
   




    

    <?php echo $__env->make('layouts.partials.admin_footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </main>



    
    <?php echo $__env->make('layouts.partials.admin_js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\layouts\vendor_Home_page.blade.php ENDPATH**/ ?>