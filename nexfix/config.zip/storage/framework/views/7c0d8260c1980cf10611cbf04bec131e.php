;
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>My Payments</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($payments->count() > 0): ?>
        <table class="table table-striped mt-3">
            <thead>
                <tr>
                    <th>Service</th>
                    <th>Vendor</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($payment->service->name ?? 'N/A'); ?></td>
                        <td><?php echo e($payment->vendor->name ?? 'N/A'); ?></td>
                        <td><?php echo e($payment->amount); ?></td>
                        <td><?php echo e(ucfirst($payment->status ?? 'Pending')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have no payments yet.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\user\user_payment.blade.php ENDPATH**/ ?>