<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Edit Booking</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('bookings.update', $booking->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>User</label>
            <select name="user_id" class="form-control" required>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e($booking->user_id == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Service</label>
            <select name="service_id" id="service_id" class="form-control" required>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($service->id); ?>"
                        <?php echo e(optional($booking->vendorService)->service_id == $service->id ? 'selected' : ''); ?>>
                        <?php echo e($service->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Vendor</label>
            <select name="vendor_id" id="vendor_id" class="form-control" required>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($vendor->id); ?>"
                        <?php echo e($booking->vendorService?->vendor_id == $vendor->id ? 'selected' : ''); ?>>
                        <?php echo e($vendor->company_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Booking Date</label>
            <input type="date" name="booking_date" value="<?php echo e($booking->booking_date); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Scheduled At</label>
            <input type="datetime-local" name="scheduled_at" value="<?php echo e($booking->scheduled_at); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Address</label>
            <input type="text" name="address" value="<?php echo e($booking->address); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Total Amount</label>
            <input type="number" step="0.01" name="total_amount" value="<?php echo e($booking->total_amount); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label>Payment Status</label>
            <select name="payment_status" class="form-control" required>
                <option value="unpaid" <?php echo e($booking->payment_status == 'unpaid' ? 'selected' : ''); ?>>Unpaid</option>
                <option value="paid" <?php echo e($booking->payment_status == 'paid' ? 'selected' : ''); ?>>Paid</option>
            </select>
        </div>

        <!-- 🟢 CHANGED: Split old Status into User + Vendor Status -->
        <div class="mb-3">
            <label>User Status</label>
            <select name="status_user" class="form-control">
                <option value="">--</option>
                <option value="completed" <?php echo e($booking->status_user == 'completed' ? 'selected' : ''); ?>>Completed</option>
                <option value="cancelled" <?php echo e($booking->status_user == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Vendor Status</label>
            <select name="status_vendor" class="form-control">
                <option value="">--</option>
                <option value="accepted" <?php echo e($booking->status_vendor == 'accepted' ? 'selected' : ''); ?>>Accepted</option>
                <option value="completed" <?php echo e($booking->status_vendor == 'completed' ? 'selected' : ''); ?>>Completed</option>
                <option value="cancelled" <?php echo e($booking->status_vendor == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Notes</label>
            <textarea name="notes" class="form-control"><?php echo e($booking->notes); ?></textarea>
        </div>

        <button type="submit" class="btn btn-success">Update Booking</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_Home_page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\admin\bookings\edit.blade.php ENDPATH**/ ?>