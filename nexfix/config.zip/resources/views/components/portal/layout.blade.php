<x-portal.header/>
    

<body>

   <x-portal.navbar/>

<main>
    {{ $slot  }}
</main>
    
  <x-portal.footer />

</body>

</html>
