<!-- Footer Start -->
            <div class="container-fluid pt-4 px-4 fixed-bottom ">
                <hr>
                <div class="bg-light  p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center t">
                            &copy; <a href="https://mahidulkabir.top">Mahidul Kabir</a>, All Right Reserved. 
                        </div>
                        <div class="col-12 col-sm-6 text-center ">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                          <span class="me-4 text-primary fw-bold">Nexfix Service Station</span> 
                    <br>
                        <span class="text-warning">Fixing life’s little problems —  </span> <span class="text-danger"> fast.</span>
                        </div>
                    </div>
                </div>
                <hr>
            </div>
            <!-- Footer End --><?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\layouts\partials\admin_footer.blade.php ENDPATH**/ ?>