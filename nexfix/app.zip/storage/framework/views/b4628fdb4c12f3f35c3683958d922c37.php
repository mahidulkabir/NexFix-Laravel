<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <title>User Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans antialiased">

    
    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <nav class="bg-blue-100 border-b border-blue-200 p-4 flex space-x-4">
        <a href="<?php echo e(route('user.dashboard')); ?>" class="text-blue-800">Dashboard</a>
        

    
    <main class="p-6">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\NexFix-Laravel\nexfix\resources\views\layouts\user.blade.php ENDPATH**/ ?>